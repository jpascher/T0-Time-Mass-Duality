# FFGFT Galois-Bündel v2 — vollständige Ableitungskette

**Datum:** 2026-09-02  
**Autor:** Johann Pascher · ORCID 0009-0000-6518-4064  
**Basis:** v1.3.5 · DOI 10.5281/zenodo.22180969  
**Prüfung:** 23/23 Skripte bestanden, 0 fehlgeschlagen

## Neu in v2 gegenüber v1

- Dok. 341 (GF(27) in GALG — algebraische Brücke FFGFT↔GALG) hinzugefügt
- pruef_341_gf27_in_galg.py (6 Assertions [B]) — erklärt Dougs Suchergebnis algebraisch zwingend
- pruef_341_vakuum_witt_z3.py / pruef_342_vakuum_witt_z3.py (7 Assertions [B])

## Galois-Kern (Ebene 0)

| Dok. | Inhalt | Marker |
|------|--------|--------|
| 317 | KSAU-FFGFT-Leptonen-Synthese | [B][K][S] |
| 321 | SU(3)_c aus ℤ₃-Trialität | [B][K][S] |
| 323 | Weinberg-Winkel, RGE | [B][K][S] |
| 324 | G(6,ℤ₃ℂ)–FFGFT-Vergleich, Trine T³=1 | [B][K][S] |
| 336 | GF(9) als FFGFT-Brücke | [B][K][S] |
| 337 | Zeitemergienz FFGFT vs. GALG | [B][K][S] |
| 338 | Galois-Feldmassen, ξ aus GF(3ⁿ) | [K] |
| 339 | Frobenius-Trennung auf GF(27)* | [B][K] |
| 340 | Neutrino-Massenhierarchie aus GF(27)* | [B][K] |
| 341 | GF(27) in GALG — algebraische Brücke FFGFT↔GALG | [B] |

## Ableitungskette (Ebene 1 — via R105 zertifiziert)

Dok. 006 [K], 011 [K], 070 [B], 182 [K], 231 [B], 257 [K],
285 [K], 306 [K], 307 [K], 332 (Vergleichsaufsatz), 333 [B]

## Prüfskripte — alle 23 bestanden

### Dok320_321_322_Skripte/
pruef_324 [B] · pruef_325 [B] · pruef_326 [B/K] · pruef_327 [B]
pruef_328 [B/K] · pruef_329 [K] · pruef_341 [B] · pruef_342 [B]

### Dok328_Skripte/
pruef_328_4_mischwinkel · pruef_328_5_messkontinuum

### Dok330_Skripte/
pruef_330_1_haar_d4 · pruef_330_2_fixpunkte_rn

### Dok332_Skripte/
pruef_332_krueger · pruef_339_frobenius [B] · pruef_340_neutrino [K]
pruef_340b_spirale · sicc_kappa_analysis

### Dok338_Skripte/
pruef_330_galois_massverh. [K] · pruef_331_xi_galois [K] · pruef_332_alpha [K]

### Dok341_Skripte/
pruef_341_gf27_in_galg [B] · pruef_341_vakuum_witt_z3 [B]

### Dok342_Skripte/
pruef_342_vakuum_witt_z3 [B]
