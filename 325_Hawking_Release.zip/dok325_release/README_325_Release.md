# Dok. 325 — FFGFT-Hawking-Mechanismus: Release-Paket

**Johann Pascher · ORCID 0009-0000-6518-4064 · August 2026**

## Inhalt

### Dokument
- `pdf/325_Hawking_FFGFT_De.pdf` — Hauptdokument (Deutsch)
- `pdf/325_Hawking_FFGFT_En.pdf` — Hauptdokument (Englisch)
- `Sources/325_Hawking_FFGFT_De_ch.tex` — LaTeX-Quelle (Deutsch)
- `Sources/325_Hawking_FFGFT_En_ch.tex` — LaTeX-Quelle (Englisch)

### Prüfskripte (alle Assertions bestanden)
- `python/325_hawking_ffgft_mechanismus.py` — Thermodynamische Kette: KMS, Membran-Thermometer, Horizont-Bit, Flächenbilanz, FFGFT-Korrektur, Verdampfung, Familienleiter, Informationsseite (8/8 OK)
- `python/325_hawking_z3_selektion.py` — ℤ₃-Algebra: Projektoren, Absorption, Trialitätsselektion, Ladungserhaltung, Sektorinformation, Masselosigkeit (6/6 OK)
- `python/325_informationsbilanz.py` — Quantitative Informationsbilanz: Endpunkt, Gesamtemission, Strukturkonstante log₂3 (9/9 OK)

## Ergebnisse (Marker-Status)

| Element | Status |
|---------|--------|
| KMS-Regel für Unruh/GH/BH gemeinsam | [K] (Dok. 313) |
| Membran-Periode aus T̃·m=1 | [K] |
| k_B T_H = E_bit(4πr_s) — Quant = Horizont-Bit | [K] (neu) |
| Flächenquant −4ℓ²_P/nat aus Bekenstein+Clausius | [B] (neu) |
| ℤ₃-Absorption P_j P_k = 0 | [B] (neu) |
| T_R=0-Selektion; Confinement = Hawking-Selektion | [B] (neu) |
| Träger = n₄-freie Torusmode | [K] (neu) |
| Sektorinfo log₂3 Bit orthogonal lesbar | [B] (neu) |
| Informationserhalt (Membran + Unitarität) | [K] (313/322) |
| FFGFT-Leistungskorrektur 0.6–1.4% | [K] (313) |
| Graukörper-Faktoren, Modenspektrum-Detail | [S] (offen) |
| Rückreaktion auf Orbifold-Fixpunkte | [S] (offen) |

## Abhängigkeiten

- Dok. 313 (KMS-Rahmen, Hawking auf dem Zeitzyklus)
- Dok. 321 (SU(3)_c aus ℤ₃-Trialität)
- Dok. 322 (Spektraltheorie, Unitarität)
- Dok. 257, 302, A271–A273 (systemabhängige Bit-Energie)
- Dok. 180 (Herleitung L₀)
- Dok. 329 (Kollapsgrenze M_coll)

## Gefrorenes Quellobjekt (CP-Test, 30. August 2026)

Dieses Dokument wurde als Quellobjekt für den operativen Test des Constitutional Protocol (CP, S. Vossen) eingefroren. Die Quell-Aussage einschließlich Marker-Status, Randbedingungen und Autor-Disposition ist in der Korrespondenz vom 30. August 2026 dokumentiert.

