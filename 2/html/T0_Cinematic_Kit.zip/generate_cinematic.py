#!/usr/bin/env python3
"""
Record T0 Cinematic Short — Playwright video capture at 30fps.

Captures the full HTML animation with particles, glows, transitions
and outputs MP4. Adds TTS narration and combines to final video.

Usage:
  python generate_cinematic.py               # DE
  python generate_cinematic.py --lang en     # EN
  python generate_cinematic.py --no-audio    # Video only
"""

import os, sys, subprocess, tempfile, argparse, io, shutil
from pathlib import Path

WIDTH = 1080
HEIGHT = 1920
SCENE_DURATIONS = [8, 10, 12, 10, 12, 10, 8]  # seconds per scene
TOTAL_DURATION = sum(SCENE_DURATIONS) + 5  # +5s buffer

NARRATION = {
    "de": [
        "Was, wenn die gesamte Physik aus einer einzigen Zahl folgen wuerde? Keine 20 Parameter. Kein Feintuning. Eine einzige geometrische Zahl.",
        "Der Parameter Xi. Vier geteilt durch dreissigtausend. Ein dimensionsloses Verhaeltnis aus der tetraedrischen Kugelpackung. Die Windungszahl des fundamentalen Torus der Raumzeit.",
        "Aus Xi folgt jede Teilchenmasse. Elektron, Myon, Tau, alle Quarks. Jede einzelne Masse wird berechnet, nicht angepasst. Die Abweichungen vom Experiment liegen unter einem Prozent. Alles aus einer Zahl.",
        "Das Standardmodell braucht ueber 20 freie Parameter. T0 braucht genau einen. Gleiche experimentelle Uebereinstimmung. Zwanzigmal weniger Parameter. Ockhams Rasiermesser hat ein klares Urteil.",
        "Die Ableitungskaskade: Aus Xi folgt die Feinstrukturkonstante Alpha. Daraus alle Teilchenmassen. Die fraktale Korrektur K fraktal. Die Gravitationskonstante G, abgeleitet, nicht eingefuegt. Und schliesslich die Zeit-Masse-Dualitaet: T mal m gleich eins.",
        "Und das Beste: T0 ist testbar. Belle 2 kann die Tau-Anomalie messen. Die Rotverschiebung entsteht in T0 durch fraktale Wegverlaengerung. Die g minus 2 Korrektur stimmt auf null Komma null eins vier Prozent.",
        "T0-Theorie. Ein Parameter. Die gesamte Physik. Johann Pascher.",
    ],
    "en": [
        "What if all of physics came from one single number? Not twenty parameters. Not fine-tuning. One single geometric number.",
        "The parameter Xi. Four divided by thirty thousand. A dimensionless ratio from tetrahedral sphere packing. The winding number of spacetime's fundamental torus.",
        "From Xi follows every particle mass. Electron, muon, tau, all quarks. Each mass is calculated, not fitted. Deviations from experiment are below one percent. All from one number.",
        "The Standard Model needs over 20 free parameters. T-zero needs exactly one. Same experimental agreement. Twenty times fewer parameters. Occam's Razor has a clear verdict.",
        "The derivation cascade: From Xi follows the fine structure constant Alpha. Then all particle masses. The fractal correction K-fractal. The gravitational constant G, derived, not inserted. And finally time-mass duality: T times m equals one.",
        "And the best part: T-zero is testable. Belle Two can measure the tau anomaly. Redshift arises from fractal path lengthening. The g minus 2 correction matches to zero point zero one four percent.",
        "T-zero Theory. One parameter. All of physics. Johann Pascher.",
    ],
}


# ============================================================
# TTS ENGINE (reuse from other scripts)
# ============================================================
def detect_engine():
    """Auto-detect working TTS engine."""
    # Try edge-tts
    try:
        import edge_tts, asyncio
        async def test():
            c = edge_tts.Communicate("Test", "de-DE-ConradNeural")
            await c.save("/tmp/_tts_test.mp3")
        asyncio.run(test())
        if os.path.exists("/tmp/_tts_test.mp3") and os.path.getsize("/tmp/_tts_test.mp3") > 1000:
            os.remove("/tmp/_tts_test.mp3")
            return "edge"
    except:
        pass
    # Try gTTS
    try:
        from gtts import gTTS
        buf = io.BytesIO()
        gTTS("Test", lang="de").write_to_fp(buf)
        if buf.tell() > 500:
            return "gtts"
    except:
        pass
    # pyttsx3 fallback
    try:
        import pyttsx3
        return "pyttsx3"
    except:
        pass
    return None


def generate_tts(text, lang, path, engine):
    """Generate TTS audio file."""
    try:
        if engine == "edge":
            import edge_tts, asyncio
            voice = "de-DE-ConradNeural" if lang == "de" else "en-US-GuyNeural"
            asyncio.run(edge_tts.Communicate(text, voice).save(path))
        elif engine == "gtts":
            from gtts import gTTS
            gTTS(text=text, lang=lang, slow=False).save(path)
        elif engine == "pyttsx3":
            import pyttsx3
            e = pyttsx3.init()
            e.setProperty('rate', 155)
            e.save_to_file(text, path)
            e.runAndWait()
        return os.path.exists(path) and os.path.getsize(path) > 500
    except Exception as ex:
        print(f"      TTS error: {ex}")
        return False


def get_audio_duration(path):
    """Get duration of audio file in seconds."""
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True, timeout=10)
        return float(r.stdout.strip())
    except:
        return 0


# ============================================================
# VIDEO RECORDING
# ============================================================
def record_html(html_path, video_path, duration_sec):
    """Record HTML animation as video using Playwright."""
    from playwright.sync_api import sync_playwright

    html_url = Path(html_path).resolve().as_uri()
    print(f"  🎬 Recording {duration_sec}s from {html_url}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={"width": WIDTH, "height": HEIGHT},
            record_video_dir=str(Path(video_path).parent),
            record_video_size={"width": WIDTH, "height": HEIGHT},
        )
        page = context.new_page()
        page.goto(html_url, wait_until="networkidle")

        # Wait for full animation to play
        print(f"    ⏱️  Recording for {duration_sec}s...")
        page.wait_for_timeout(duration_sec * 1000)

        # Close to finalize video
        context.close()
        browser.close()

    # Find the recorded video (Playwright names it randomly)
    video_dir = Path(video_path).parent
    webm_files = sorted(video_dir.glob("*.webm"), key=os.path.getmtime, reverse=True)
    if webm_files:
        recorded = webm_files[0]
        # Convert webm to mp4
        print(f"    🔄 Converting {recorded.name} → mp4")
        cmd = [
            "ffmpeg", "-y", "-i", str(recorded),
            "-c:v", "libx264", "-preset", "fast",
            "-pix_fmt", "yuv420p",
            "-r", "30",
            video_path
        ]
        subprocess.run(cmd, capture_output=True, timeout=300)
        os.remove(recorded)
        return os.path.exists(video_path)
    return False


# ============================================================
# COMBINE VIDEO + AUDIO
# ============================================================
def combine_audio_scenes(tmpdir, lang, engine):
    """Generate per-scene audio, concatenate to single track."""
    texts = NARRATION.get(lang, NARRATION["en"])
    scene_audios = []
    total_audio_dur = 0

    for i, text in enumerate(texts):
        audio_path = os.path.join(tmpdir, f"narr_{i:02d}.mp3")
        target_dur = SCENE_DURATIONS[i]

        if generate_tts(text, lang, audio_path, engine):
            actual_dur = get_audio_duration(audio_path)

            # Pad audio with silence to match scene duration
            padded = os.path.join(tmpdir, f"narr_pad_{i:02d}.mp3")
            silence_dur = max(0, target_dur - actual_dur)
            cmd = [
                "ffmpeg", "-y",
                "-i", audio_path,
                "-af", f"apad=pad_dur={silence_dur}",
                "-t", str(target_dur),
                "-c:a", "aac", "-b:a", "192k",
                padded
            ]
            subprocess.run(cmd, capture_output=True, timeout=60)
            scene_audios.append(padded)
            total_audio_dur += target_dur
            print(f"    🔊 Scene {i+1}: {actual_dur:.1f}s audio → {target_dur}s padded")
        else:
            # Generate silence for this scene
            silent = os.path.join(tmpdir, f"narr_pad_{i:02d}.mp3")
            cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i",
                   f"anullsrc=r=44100:cl=stereo", "-t", str(target_dur),
                   "-c:a", "aac", silent]
            subprocess.run(cmd, capture_output=True, timeout=30)
            scene_audios.append(silent)
            total_audio_dur += target_dur

    # Concat all audio
    concat_file = os.path.join(tmpdir, "audio_concat.txt")
    with open(concat_file, "w") as f:
        for a in scene_audios:
            f.write(f"file '{os.path.basename(a)}'\n")

    full_audio = os.path.join(tmpdir, "full_narration.aac")
    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0",
           "-i", concat_file, "-c", "copy", full_audio]
    subprocess.run(cmd, capture_output=True, cwd=tmpdir, timeout=120)
    print(f"    📻 Full narration: {total_audio_dur:.1f}s")
    return full_audio if os.path.exists(full_audio) else None


def merge_video_audio(video_path, audio_path, output_path):
    """Merge video and audio into final output."""
    cmd = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-i", audio_path,
        "-c:v", "copy",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest",
        output_path
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    return r.returncode == 0


# ============================================================
# MAIN
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="T0 Cinematic Short Generator")
    parser.add_argument("--lang", default="de", choices=["de", "en", "both"])
    parser.add_argument("--engine", default=None, choices=["edge", "gtts", "pyttsx3"])
    parser.add_argument("--no-audio", action="store_true")
    parser.add_argument("--html", default=None, help="Path to HTML file")
    args = parser.parse_args()

    languages = ["de", "en"] if args.lang == "both" else [args.lang]

    engine = args.engine or detect_engine()
    if engine and not args.no_audio:
        print(f"  🎤 TTS Engine: {engine}")
    elif not args.no_audio:
        print("  ⚠️  No TTS engine found — video only")
        args.no_audio = True

    for lang in languages:
        print(f"\n{'='*60}")
        print(f"  T0 CINEMATIC SHORT — {lang.upper()}")
        print(f"{'='*60}")

        html_file = args.html or f"T0_Cinematic_{lang.upper()}.html"
        if not os.path.exists(html_file):
            html_file = os.path.join(os.path.dirname(__file__), f"T0_Cinematic_{lang.upper()}.html")
        if not os.path.exists(html_file):
            print(f"  ❌ HTML not found: {html_file}")
            continue

        output = f"T0_Cinematic_{lang.upper()}.mp4"

        with tempfile.TemporaryDirectory() as tmpdir:
            raw_video = os.path.join(tmpdir, "raw.mp4")

            # Step 1: Record HTML animation
            print("\n  📹 Step 1: Recording animation...")
            if not record_html(html_file, raw_video, TOTAL_DURATION):
                print("  ❌ Recording failed!")
                continue

            if args.no_audio:
                shutil.copy2(raw_video, output)
            else:
                # Step 2: Generate narration
                print("\n  🎙️  Step 2: Generating narration...")
                audio = combine_audio_scenes(tmpdir, lang, engine)

                if audio:
                    # Step 3: Merge
                    print("\n  🔗 Step 3: Merging video + audio...")
                    if merge_video_audio(raw_video, audio, output):
                        dur = get_audio_duration(output)
                        size_mb = os.path.getsize(output) / (1024*1024)
                        print(f"\n  ✅ {output} — {dur:.1f}s, {size_mb:.1f}MB")
                    else:
                        print("  ❌ Merge failed!")
                        shutil.copy2(raw_video, output)
                else:
                    shutil.copy2(raw_video, output)

    print("\n  🎬 Done!")


if __name__ == "__main__":
    main()
