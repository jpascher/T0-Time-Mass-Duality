BD12-XCORE — FFGFT mass-core declaration
========================================
Files:
  BD12_XCORE_FFGFT_Declaration.md  - the pre-registered declaration (frozen rule, criterion)
  bd12_xcore_ffgft.py              - reproducer (numpy-only; run: python3 bd12_xcore_ffgft.py)

Summary:
  Frozen rule r=sqrt2, theta=2/9 (no post-fit freedom). Reproduces Koide Q=2/3 (exact),
  m_mu/m_e to 0.001%, and predicts m_tau via Koide+{m_e,m_mu} to 0.006%.
  Matched-null: random (r,theta) reproduce the joint {Koide AND ratios} set in ~0.000% of cases.
  => PASS; a fixed transformation, not a post-hoc fit. Symmetric: random inputs -> FAIL.

  Constraints: do NOT dock on L_nat (carrier Laplacian); the map is a fixed reformulation,
  no new physics. The dock run (does the HLV carrier admit it?) is performed on the HLV side.
