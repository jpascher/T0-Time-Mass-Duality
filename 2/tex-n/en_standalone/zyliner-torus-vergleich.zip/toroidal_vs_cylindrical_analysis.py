#!/usr/bin/env python3
"""
T0 QUBIT: TOROIDAL vs. CYLINDRICAL CALCULATIONS
================================================

Vergleich der Genauigkeit zwischen:
1. Zylindrische Näherung (Standard, einfach)
2. Vollständige Torus-Geometrie (Fundamental, exakt)

Fragestellung: Reduziert die Torus-Geometrie die Ungenauigkeiten?
"""

import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Tuple, List
import time

# ============================================================================
# KONSTANTEN
# ============================================================================

XI = 4 / 30000  # ξ-Parameter
D_F = 3 - XI     # Fraktale Dimension
PHI = (1 + np.sqrt(5)) / 2  # Goldener Schnitt

# Planck-Skala Konstanten (natürliche Einheiten)
L_PLANCK = 1.616255e-35  # m
T_PLANCK = 5.391247e-44  # s

# Torus-Parameter (Proton als Beispiel)
R_MAJOR_PROTON = 0.8414e-15  # m (Protonradius)
R_TUBE_PROTON = 21 * L_PLANCK  # Sub-Planck Schlauchradius

print("="*80)
print("T0 QUBIT: TOROIDAL vs. CYLINDRICAL CALCULATIONS")
print("="*80)
print()
print("PARAMETER:")
print(f"  ξ = {XI:.6e}")
print(f"  D_f = {D_F:.10f}")
print(f"  φ = {PHI:.6f}")
print()
print("TORUS-GEOMETRIE (Proton-Skala):")
print(f"  R_major = {R_MAJOR_PROTON:.3e} m")
print(f"  r_tube = {R_TUBE_PROTON:.3e} m")
print(f"  Aspect ratio R/r = {R_MAJOR_PROTON/R_TUBE_PROTON:.3e}")
print()

# ============================================================================
# QUBIT-DARSTELLUNGEN
# ============================================================================

@dataclass
class CylindricalQubit:
    """Standard-Darstellung: Zylindrische Koordinaten"""
    z: float  # ∈ [-1, 1]
    r: float  # ∈ [0, 1]
    theta: float  # ∈ [0, 2π)
    
    def __post_init__(self):
        # Normalisierung erzwingen
        norm = np.sqrt(self.z**2 + self.r**2)
        if abs(norm - 1.0) > 1e-10:
            self.z /= norm
            self.r /= norm
    
    def energy(self) -> float:
        """Energie des Zustands (r² = Energiedichte)"""
        return self.r**2
    
    def to_cartesian_cyl(self) -> Tuple[float, float, float]:
        """Konvertiere zu kartesischen Koordinaten (Zylinder)"""
        x = self.r * np.cos(self.theta)
        y = self.r * np.sin(self.theta)
        return x, y, self.z


@dataclass
class ToroidalQubit:
    """Fundamentale Darstellung: Toroidale Koordinaten"""
    R: float  # Major radius (toroidal)
    r_tube: float  # Tube radius
    theta_tor: float  # Toroidal angle ∈ [0, 2π)
    theta_pol: float  # Poloidal angle ∈ [0, 2π)
    
    def to_cartesian_torus(self) -> Tuple[float, float, float]:
        """Konvertiere zu kartesischen Koordinaten (Torus)"""
        x = (self.R + self.r_tube * np.cos(self.theta_pol)) * np.cos(self.theta_tor)
        y = (self.R + self.r_tube * np.cos(self.theta_pol)) * np.sin(self.theta_tor)
        z = self.r_tube * np.sin(self.theta_pol)
        return x, y, z
    
    def to_cylindrical(self) -> CylindricalQubit:
        """Konvertiere Torus → Zylinder (Approximation)"""
        z_cyl = self.r_tube * np.sin(self.theta_pol)
        r_cyl = self.r_tube * np.cos(self.theta_pol)
        theta_cyl = self.theta_tor
        
        # Normalisieren auf Einheitskreis
        norm = np.sqrt(z_cyl**2 + r_cyl**2)
        if norm > 0:
            z_cyl /= norm
            r_cyl /= norm
        
        return CylindricalQubit(z_cyl, r_cyl, theta_cyl)
    
    def energy_torus(self) -> float:
        """Energie auf Torus-Oberfläche (mit fraktaler Korrektur)"""
        # Energiedichte ∝ Abstand von Symmetrieachse
        rho = self.R + self.r_tube * np.cos(self.theta_pol)
        
        # Fraktale Korrektur
        fractal_factor = 1 - XI * np.log(self.R / L_PLANCK) / D_F
        
        return (self.r_tube**2) * fractal_factor


@dataclass
class HybridQubit:
    """Hybrid: Zylinder mit Torus-Korrekturen"""
    z: float
    r: float
    theta: float
    R_major: float  # Torus major radius (für Korrekturen)
    
    def __post_init__(self):
        norm = np.sqrt(self.z**2 + self.r**2)
        if abs(norm - 1.0) > 1e-10:
            self.z /= norm
            self.r /= norm
    
    def curvature_correction(self) -> float:
        """Krümmungskorrektur von Torus"""
        return self.r / self.R_major
    
    def energy_corrected(self) -> float:
        """Energie mit Torus-Korrektur"""
        E_cyl = self.r**2
        
        # Erste Ordnung Korrektur: O(r/R)
        correction = self.curvature_correction()
        
        # Zweite Ordnung: O((r/R)²)
        correction2 = correction**2
        
        return E_cyl * (1 + XI * correction - 0.5 * correction2)


# ============================================================================
# GATE-OPERATIONEN
# ============================================================================

def hadamard_cylindrical(q: CylindricalQubit, n_qubits: int = 1) -> CylindricalQubit:
    """Standard T0-Hadamard (zylindrisch)"""
    damping = np.exp(-XI * np.log(n_qubits) / D_F)
    
    z_new = q.r * damping
    r_new = q.z * damping
    theta_new = q.theta + np.pi / 2
    
    return CylindricalQubit(z_new, r_new, theta_new)


def hadamard_toroidal(q: ToroidalQubit, n_qubits: int = 1) -> ToroidalQubit:
    """Fundamentales T0-Hadamard auf Torus"""
    damping = np.exp(-XI * np.log(n_qubits) / D_F)
    
    # Hadamard = π/2 Rotation um Y-Achse in Bloch-Darstellung
    # Auf Torus: Swap poloidal ↔ toroidal mit Dämpfung
    
    theta_pol_new = q.theta_tor
    theta_tor_new = q.theta_pol + np.pi / 2
    
    # Radius-Anpassung für Bell-Dämpfung
    r_tube_new = q.r_tube * damping
    R_new = q.R * damping
    
    return ToroidalQubit(R_new, r_tube_new, theta_tor_new, theta_pol_new)


def hadamard_hybrid(q: HybridQubit, n_qubits: int = 1) -> HybridQubit:
    """Hybrid Hadamard mit Torus-Korrekturen"""
    damping = np.exp(-XI * np.log(n_qubits) / D_F)
    
    # Basis-Transformation wie zylindrisch
    z_new = q.r * damping
    r_new = q.z * damping
    theta_new = q.theta + np.pi / 2
    
    # ZUSÄTZLICH: Torus-Krümmungskorrektur
    curvature = q.r / q.R_major
    torus_correction = 1 + XI * curvature
    
    z_new *= torus_correction
    r_new *= torus_correction
    
    return HybridQubit(z_new, r_new, theta_new, q.R_major)


# ============================================================================
# BELL-KORRELATIONEN
# ============================================================================

def bell_correlation_cylindrical(angle_a: float, angle_b: float, n_qubits: int = 2) -> float:
    """Bell-Korrelation (zylindrisch)"""
    damping = np.exp(-XI * np.log(n_qubits) / D_F)
    delta = angle_a - angle_b
    return -np.cos(delta) * damping


def bell_correlation_toroidal(angle_a: float, angle_b: float, 
                               R_major: float, r_tube: float, 
                               n_qubits: int = 2) -> float:
    """Bell-Korrelation auf Torus (exakt)"""
    # Basis-Korrelation
    delta = angle_a - angle_b
    E_base = -np.cos(delta)
    
    # Torus-spezifische Dämpfung
    # Berücksichtigt Krümmung + fraktale Dimension
    aspect_ratio = R_major / r_tube
    
    # Logarithmische Dämpfung (wie zylindrisch)
    log_damping = np.exp(-XI * np.log(n_qubits) / D_F)
    
    # NEUE: Krümmungs-abhängige Dämpfung
    curvature_damping = np.exp(-XI * delta**2 / (np.pi**2 * aspect_ratio))
    
    # Fraktale Korrektur
    fractal_correction = 1 - XI * np.log(aspect_ratio) / D_F
    
    return E_base * log_damping * curvature_damping * fractal_correction


def bell_correlation_hybrid(angle_a: float, angle_b: float,
                             R_major: float, n_qubits: int = 2) -> float:
    """Hybrid Bell-Korrelation (zylindrisch + erste Ordnung Torus-Korrektur)"""
    delta = angle_a - angle_b
    E_cyl = -np.cos(delta)
    
    # Basis-Dämpfung
    log_damping = np.exp(-XI * np.log(n_qubits) / D_F)
    
    # Erste Ordnung Krümmungskorrektur
    # Normalisiere R_major zu sinnvollem Bereich
    # Für sehr große R/r: Korrektur wird vernachlässigbar klein
    if R_major > 1e10:
        curvature_correction = 1.0  # Keine Korrektur bei extrem großem R
    else:
        # r_tube ≈ 1 (normalisiert)
        curvature_correction = 1 + XI * (1 / R_major) * (delta / np.pi)**2
    
    return E_cyl * log_damping * curvature_correction


# ============================================================================
# CHSH-PARAMETER BERECHNUNG
# ============================================================================

def compute_chsh_cylindrical(n_qubits: int) -> dict:
    """CHSH mit zylindrischer Geometrie"""
    angles = [
        (0, np.pi/4),
        (0, 3*np.pi/4),
        (np.pi/2, np.pi/4),
        (np.pi/2, 3*np.pi/4)
    ]
    
    correlations = [bell_correlation_cylindrical(a, b, n_qubits) for a, b in angles]
    chsh = abs(correlations[0] - correlations[1] + correlations[2] + correlations[3])
    
    return {
        'chsh': chsh,
        'correlations': correlations,
        'method': 'cylindrical'
    }


def compute_chsh_toroidal(n_qubits: int, R_major: float, r_tube: float) -> dict:
    """CHSH mit toroidaler Geometrie"""
    angles = [
        (0, np.pi/4),
        (0, 3*np.pi/4),
        (np.pi/2, np.pi/4),
        (np.pi/2, 3*np.pi/4)
    ]
    
    correlations = [bell_correlation_toroidal(a, b, R_major, r_tube, n_qubits) 
                   for a, b in angles]
    chsh = abs(correlations[0] - correlations[1] + correlations[2] + correlations[3])
    
    return {
        'chsh': chsh,
        'correlations': correlations,
        'method': 'toroidal',
        'aspect_ratio': R_major / r_tube
    }


def compute_chsh_hybrid(n_qubits: int, R_major: float) -> dict:
    """CHSH mit Hybrid-Ansatz"""
    angles = [
        (0, np.pi/4),
        (0, 3*np.pi/4),
        (np.pi/2, np.pi/4),
        (np.pi/2, 3*np.pi/4)
    ]
    
    correlations = [bell_correlation_hybrid(a, b, R_major, n_qubits) 
                   for a, b in angles]
    chsh = abs(correlations[0] - correlations[1] + correlations[2] + correlations[3])
    
    return {
        'chsh': chsh,
        'correlations': correlations,
        'method': 'hybrid'
    }


# ============================================================================
# VERGLEICHENDE ANALYSE
# ============================================================================

def analyze_accuracy_vs_aspect_ratio():
    """Analysiere Genauigkeit als Funktion von R/r"""
    
    print("="*80)
    print("ANALYSE: GENAUIGKEIT vs. ASPECT RATIO (R/r)")
    print("="*80)
    print()
    
    n_qubits = 73  # IBM Test
    chsh_qm = 2 * np.sqrt(2)
    chsh_observed = 2.8275  # IBM Messung
    
    # Verschiedene Aspect Ratios testen
    aspect_ratios = np.logspace(1, 20, 20)  # 10¹ bis 10²⁰
    
    results = {
        'aspect_ratios': [],
        'chsh_cylindrical': [],
        'chsh_toroidal': [],
        'chsh_hybrid': [],
        'error_cylindrical': [],
        'error_toroidal': [],
        'error_hybrid': []
    }
    
    for AR in aspect_ratios:
        # Annahme: r_tube = 1 (normalisiert)
        r_tube = 1.0
        R_major = AR * r_tube
        
        # Berechne CHSH mit allen drei Methoden
        res_cyl = compute_chsh_cylindrical(n_qubits)
        res_tor = compute_chsh_toroidal(n_qubits, R_major, r_tube)
        res_hyb = compute_chsh_hybrid(n_qubits, R_major)
        
        # Speichere Ergebnisse
        results['aspect_ratios'].append(AR)
        results['chsh_cylindrical'].append(res_cyl['chsh'])
        results['chsh_toroidal'].append(res_tor['chsh'])
        results['chsh_hybrid'].append(res_hyb['chsh'])
        
        # Fehler relativ zu Messung
        results['error_cylindrical'].append(abs(res_cyl['chsh'] - chsh_observed))
        results['error_toroidal'].append(abs(res_tor['chsh'] - chsh_observed))
        results['error_hybrid'].append(abs(res_hyb['chsh'] - chsh_observed))
    
    # Ausgabe
    print("ASPECT RATIO vs. CHSH-WERT:")
    print(f"{'R/r':<15} {'Cylindrical':<15} {'Toroidal':<15} {'Hybrid':<15} {'Best':<10}")
    print("-"*80)
    
    for i in range(0, len(aspect_ratios), len(aspect_ratios)//10):
        AR = results['aspect_ratios'][i]
        c_cyl = results['chsh_cylindrical'][i]
        c_tor = results['chsh_toroidal'][i]
        c_hyb = results['chsh_hybrid'][i]
        
        errors = [
            results['error_cylindrical'][i],
            results['error_toroidal'][i],
            results['error_hybrid'][i]
        ]
        best = ['Cyl', 'Tor', 'Hyb'][np.argmin(errors)]
        
        print(f"{AR:<15.2e} {c_cyl:<15.6f} {c_tor:<15.6f} {c_hyb:<15.6f} {best:<10}")
    
    print()
    print("FEHLER-ANALYSE (Δ zu IBM-Messung 2.8275):")
    print(f"{'R/r':<15} {'Δ Cyl':<15} {'Δ Tor':<15} {'Δ Hyb':<15} {'Verbesserung':<15}")
    print("-"*80)
    
    for i in range(0, len(aspect_ratios), len(aspect_ratios)//10):
        AR = results['aspect_ratios'][i]
        e_cyl = results['error_cylindrical'][i]
        e_tor = results['error_toroidal'][i]
        e_hyb = results['error_hybrid'][i]
        
        # Verbesserung gegenüber zylindrisch
        improvement_tor = (e_cyl - e_tor) / e_cyl * 100 if e_cyl > 0 else 0
        improvement_hyb = (e_cyl - e_hyb) / e_cyl * 100 if e_cyl > 0 else 0
        
        best_improvement = max(improvement_tor, improvement_hyb)
        
        print(f"{AR:<15.2e} {e_cyl:<15.6e} {e_tor:<15.6e} {e_hyb:<15.6e} {best_improvement:<15.2f}%")
    
    return results


def analyze_proton_scale():
    """Spezifische Analyse für Proton-Skala"""
    
    print()
    print("="*80)
    print("SPEZIAL-ANALYSE: PROTON-SKALA TORUS")
    print("="*80)
    print()
    
    n_qubits = 73
    chsh_observed = 2.8275
    
    # Proton Parameter
    R_major = R_MAJOR_PROTON
    r_tube = R_TUBE_PROTON
    AR = R_major / r_tube
    
    print(f"PROTON PARAMETER:")
    print(f"  R_major = {R_major:.3e} m")
    print(f"  r_tube = {r_tube:.3e} m")
    print(f"  Aspect Ratio = {AR:.3e}")
    print()
    
    # Berechne alle drei Methoden
    res_cyl = compute_chsh_cylindrical(n_qubits)
    res_tor = compute_chsh_toroidal(n_qubits, R_major, r_tube)
    res_hyb = compute_chsh_hybrid(n_qubits, R_major)
    
    print("CHSH-PARAMETER VERGLEICH:")
    print(f"  Standard QM:    {2*np.sqrt(2):.6f}")
    print(f"  IBM Observed:   {chsh_observed:.6f}")
    print(f"  Cylindrical:    {res_cyl['chsh']:.6f}  (Δ = {abs(res_cyl['chsh'] - chsh_observed):.6e})")
    print(f"  Toroidal:       {res_tor['chsh']:.6f}  (Δ = {abs(res_tor['chsh'] - chsh_observed):.6e})")
    print(f"  Hybrid:         {res_hyb['chsh']:.6f}  (Δ = {abs(res_hyb['chsh'] - chsh_observed):.6e})")
    print()
    
    # Verbesserung berechnen
    error_cyl = abs(res_cyl['chsh'] - chsh_observed)
    error_tor = abs(res_tor['chsh'] - chsh_observed)
    error_hyb = abs(res_hyb['chsh'] - chsh_observed)
    
    improvement_tor = (error_cyl - error_tor) / error_cyl * 100 if error_cyl > 0 else 0
    improvement_hyb = (error_cyl - error_hyb) / error_cyl * 100 if error_cyl > 0 else 0
    
    print("VERBESSERUNG GEGENÜBER ZYLINDRISCH:")
    print(f"  Toroidal:  {improvement_tor:+.2f}%")
    print(f"  Hybrid:    {improvement_hyb:+.2f}%")
    print()
    
    # Einzelne Korrelationen
    print("EINZELNE KORRELATIONEN:")
    angles = [(0, np.pi/4), (0, 3*np.pi/4), (np.pi/2, np.pi/4), (np.pi/2, 3*np.pi/4)]
    
    for i, (a, b) in enumerate(angles):
        E_cyl = res_cyl['correlations'][i]
        E_tor = res_tor['correlations'][i]
        E_hyb = res_hyb['correlations'][i]
        
        print(f"  E({a:.2f}, {b:.2f}):")
        print(f"    Cyl: {E_cyl:+.6f}  |  Tor: {E_tor:+.6f}  |  Hyb: {E_hyb:+.6f}")
        print(f"    Δ(Tor-Cyl): {E_tor - E_cyl:+.6e}  |  Δ(Hyb-Cyl): {E_hyb - E_cyl:+.6e}")
    
    return {
        'cylindrical': res_cyl,
        'toroidal': res_tor,
        'hybrid': res_hyb,
        'improvement_toroidal': improvement_tor,
        'improvement_hybrid': improvement_hyb
    }


# ============================================================================
# VISUALISIERUNG
# ============================================================================

def plot_comparison(results):
    """Visualisiere Vergleich"""
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Toroidal vs. Cylindrical T0 Qubit Calculations', 
                 fontsize=16, fontweight='bold')
    
    AR = np.array(results['aspect_ratios'])
    
    # Plot 1: CHSH vs. Aspect Ratio
    ax1 = axes[0, 0]
    ax1.semilogx(AR, results['chsh_cylindrical'], 'b-', linewidth=2, label='Cylindrical')
    ax1.semilogx(AR, results['chsh_toroidal'], 'r--', linewidth=2, label='Toroidal')
    ax1.semilogx(AR, results['chsh_hybrid'], 'g:', linewidth=2, label='Hybrid')
    ax1.axhline(y=2.8275, color='orange', linestyle='--', label='IBM Observed')
    ax1.axhline(y=2*np.sqrt(2), color='gray', linestyle=':', alpha=0.5, label='QM Limit')
    
    ax1.set_xlabel('Aspect Ratio R/r', fontsize=11)
    ax1.set_ylabel('CHSH Parameter', fontsize=11)
    ax1.set_title('CHSH vs. Torus Aspect Ratio', fontweight='bold')
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)
    
    # Plot 2: Error vs. Aspect Ratio
    ax2 = axes[0, 1]
    ax2.loglog(AR, results['error_cylindrical'], 'b-', linewidth=2, label='Cylindrical')
    ax2.loglog(AR, results['error_toroidal'], 'r--', linewidth=2, label='Toroidal')
    ax2.loglog(AR, results['error_hybrid'], 'g:', linewidth=2, label='Hybrid')
    
    ax2.set_xlabel('Aspect Ratio R/r', fontsize=11)
    ax2.set_ylabel('|CHSH - Observed| (Error)', fontsize=11)
    ax2.set_title('Prediction Error vs. Aspect Ratio', fontweight='bold')
    ax2.legend(fontsize=9)
    ax2.grid(True, alpha=0.3, which='both')
    
    # Plot 3: Improvement
    ax3 = axes[1, 0]
    improvement_tor = [(results['error_cylindrical'][i] - results['error_toroidal'][i]) / results['error_cylindrical'][i] * 100 
                       if results['error_cylindrical'][i] > 0 else 0
                       for i in range(len(AR))]
    improvement_hyb = [(results['error_cylindrical'][i] - results['error_hybrid'][i]) / results['error_cylindrical'][i] * 100 
                       if results['error_cylindrical'][i] > 0 else 0
                       for i in range(len(AR))]
    
    ax3.semilogx(AR, improvement_tor, 'r-', linewidth=2, label='Toroidal vs. Cylindrical')
    ax3.semilogx(AR, improvement_hyb, 'g-', linewidth=2, label='Hybrid vs. Cylindrical')
    ax3.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
    
    ax3.set_xlabel('Aspect Ratio R/r', fontsize=11)
    ax3.set_ylabel('Improvement (%)', fontsize=11)
    ax3.set_title('Accuracy Improvement over Cylindrical', fontweight='bold')
    ax3.legend(fontsize=9)
    ax3.grid(True, alpha=0.3)
    
    # Plot 4: Proton-Skala Highlight
    ax4 = axes[1, 1]
    
    # Zoom auf Proton-Bereich
    proton_AR = R_MAJOR_PROTON / R_TUBE_PROTON
    idx_proton = np.argmin(np.abs(AR - proton_AR))
    
    zoom_range = slice(max(0, idx_proton-5), min(len(AR), idx_proton+5))
    
    ax4.plot(AR[zoom_range], results['chsh_cylindrical'][zoom_range], 'b-o', label='Cylindrical')
    ax4.plot(AR[zoom_range], results['chsh_toroidal'][zoom_range], 'r--s', label='Toroidal')
    ax4.plot(AR[zoom_range], results['chsh_hybrid'][zoom_range], 'g:^', label='Hybrid')
    ax4.axhline(y=2.8275, color='orange', linestyle='--', label='IBM Observed')
    
    # Markiere Proton-Punkt
    ax4.axvline(x=proton_AR, color='purple', linestyle=':', alpha=0.7, label=f'Proton AR={proton_AR:.1e}')
    
    ax4.set_xscale('log')
    ax4.set_xlabel('Aspect Ratio R/r (zoom)', fontsize=11)
    ax4.set_ylabel('CHSH Parameter', fontsize=11)
    ax4.set_title('Detail: Proton-Scale Region', fontweight='bold')
    ax4.legend(fontsize=8)
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/toroidal_vs_cylindrical_analysis.png', 
                dpi=300, bbox_inches='tight')
    print("✓ Plot saved: toroidal_vs_cylindrical_analysis.png")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    
    # Analyse 1: Aspect Ratio Scan
    print("\n" + "="*80)
    print("RUNNING COMPREHENSIVE ANALYSIS...")
    print("="*80 + "\n")
    
    results = analyze_accuracy_vs_aspect_ratio()
    
    # Analyse 2: Proton-Skala
    proton_results = analyze_proton_scale()
    
    # Visualisierung
    print()
    print("="*80)
    print("CREATING VISUALIZATION...")
    print("="*80)
    print()
    
    plot_comparison(results)
    
    # Zusammenfassung
    print()
    print("="*80)
    print("ZUSAMMENFASSUNG")
    print("="*80)
    print()
    print("HAUPTERGEBNISSE:")
    print()
    print(f"1. PROTON-SKALA (R/r ≈ {R_MAJOR_PROTON/R_TUBE_PROTON:.2e}):")
    print(f"   • Toroidal verbessert Genauigkeit um: {proton_results['improvement_toroidal']:+.2f}%")
    print(f"   • Hybrid verbessert Genauigkeit um:   {proton_results['improvement_hybrid']:+.2f}%")
    print()
    
    # Finde bestes Aspect Ratio
    idx_best_tor = np.argmin(results['error_toroidal'])
    idx_best_hyb = np.argmin(results['error_hybrid'])
    
    best_AR_tor = results['aspect_ratios'][idx_best_tor]
    best_AR_hyb = results['aspect_ratios'][idx_best_hyb]
    
    print(f"2. OPTIMALE ASPECT RATIOS:")
    print(f"   • Toroidal minimal error bei R/r ≈ {best_AR_tor:.2e}")
    print(f"     → CHSH = {results['chsh_toroidal'][idx_best_tor]:.6f}")
    print(f"     → Error = {results['error_toroidal'][idx_best_tor]:.6e}")
    print()
    print(f"   • Hybrid minimal error bei R/r ≈ {best_AR_hyb:.2e}")
    print(f"     → CHSH = {results['chsh_hybrid'][idx_best_hyb]:.6f}")
    print(f"     → Error = {results['error_hybrid'][idx_best_hyb]:.6e}")
    print()
    
    # Verbesserung
    baseline_error = results['error_cylindrical'][0]  # Bei kleinster AR
    best_error_tor = results['error_toroidal'][idx_best_tor]
    best_error_hyb = results['error_hybrid'][idx_best_hyb]
    
    max_improvement_tor = (baseline_error - best_error_tor) / baseline_error * 100
    max_improvement_hyb = (baseline_error - best_error_hyb) / baseline_error * 100
    
    print(f"3. MAXIMALE VERBESSERUNG:")
    print(f"   • Toroidal: {max_improvement_tor:+.2f}% (vs. cylindrical)")
    print(f"   • Hybrid:   {max_improvement_hyb:+.2f}% (vs. cylindrical)")
    print()
    
    print("="*80)
    print("ANALYSIS COMPLETE")
    print("="*80)
